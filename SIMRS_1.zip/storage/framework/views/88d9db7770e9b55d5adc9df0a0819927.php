<?php $__env->startSection('content'); ?>
    <!DOCTYPE html>
    <html>

    <head>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.css">
        <link rel="stylesheet" href="css/kelolasuratkeluar.css">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
        <style>
            .dropdown {
                position: relative;
                display: inline-block;
            }

            .dropdown-content {
                display: none;
                position: absolute;
                background-color: #f9f9f9;
                min-width: 160px;
                box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
                z-index: 1;
            }

            .dropdown:hover .dropdown-content {
                display: block;
            }

            .dropdown-item {
                padding: 12px 16px;
                text-decoration: none;
                display: block;
                color: #333;
            }

            .dropdown-item:hover {
                background-color: #ddd;
            }
        </style>
    </head>

    <body>
        <div class="container py-5" style="background-color: blue; border-radius: 25px;">
            <div class="container py-6">
                <div class="card-header" style="background-color: blue; color: white; border-bottom: 2px solid white;">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <span class="font-weight-bold" style="font-size: 30px;">Kelola Surat Keluar</span>
                        </div>

                        <div class="">
                            <a href="<?php echo e(route('suratkeluar.create')); ?>"><button  type="button" class="button"
                                style="font-size: 15px; border-radius: 20px;">Tambah Surat Baru</button></a>
    
                        </div>

                    </div>

                    <br>
                    <div class="row py-6">
                        <div class="col-lg-12 mx-auto">
                            <div class="card rounded shadow border-2">
                                <div class="card-body p-5 bg-white rounded">
                                    <div class="button-container">
                                        <a href="<?php echo e(route('suratmasuk.index')); ?>">
                                            <div class="button" id="suratMasuk">Surat Masuk</div>
                                        </a>
                                        <a href="<?php echo e(route('suratkeluar.index')); ?>">
                                            <div class="button" id="suratMasuk">Surat Keluar</div>
                                        </a>
                                    </div>

                                    <script>
                                        // JavaScript untuk mengubah warna tombol saat diklik
                                        const suratMasukButton = document.getElementById('suratMasuk');
                                        const suratKeluarButton = document.getElementById('suratKeluar');

                                        suratMasukButton.addEventListener('click', () => {
                                            suratMasukButton.classList.add('active-button');
                                            suratKeluarButton.classList.remove('active-button');
                                        });

                                        suratKeluarButton.addEventListener('click', () => {
                                            suratKeluarButton.classList.add('active-button');
                                            suratMasukButton.classList.remove('active-button');
                                        });
                                    </script>

                                    <br><br>
                                    <div class="table-responsive">
                                        <table id="example" style="width: 100%"
                                            class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Nama Surat</th>
                                                    <th>Tanggal dibuat</th>
                                                    <th>Jenis Surat</th>
                                                    <th>Tujuan</th>
                                                    <th>Status</th>
                                                    <th>Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $no = 1;
                                                ?>
                                                <?php $__currentLoopData = $suratkeluar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suratkeluarr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($no++); ?></td>
                                                        <td><?php echo e($suratkeluarr->nama_surat); ?></td>
                                                        <td><?php echo e($suratkeluarr->tanggal_dibuat); ?></td>
                                                        <td><?php echo e($suratkeluarr->jenis_surat); ?></td>
                                                        <td><?php echo e($suratkeluarr->tujuan_surat); ?></td>
                                                        <td><?php echo e($suratkeluarr->status); ?></td>
                                                    

                                                            

                                                            
                                                            
                                                            
                                                        <td>
                                                            <a href="<?php echo e(route('suratkeluar.edit', $suratkeluarr->id)); ?>"><button
                                                                    class="btn btn-warning">
                                                                    <i class="fas fa-edit"></i></button></a>
                                                            
                                                            <?php if(auth()->user()->jabatan == "Direktur RS" && $suratkeluarr->jenis_surat=="Template" && $suratkeluarr->status != 'disetujui'): ?>
                                                            <a href="<?php echo e(route('templateSK.priview', $suratkeluarr->id)); ?>"><button
                                                                class="btn btn-warning" style="background:#1AACAC">
                                                                <i class="fa-solid fa-file-signature"></i></button></a>
                                                            <?php endif; ?>

                                            
                                                            <?php if($suratkeluarr->file): ?>
                                                                <a href="<?php echo e(route('suratkeluar.download', ['id' => $suratkeluarr->id, 'file' => $suratkeluarr->file])); ?>"
                                                                    class="btn btn-success" target="_blank"><i
                                                                        class="fas fa-download"></i></a>
                                                            <?php endif; ?>
                                                            <a href="<?php echo e(route('disposisi.showsurat', ['id' => $suratkeluarr->id, 'nama' => $suratkeluarr->nama_surat])); ?>"><button
                                                                    class="btn btn-primary"><i
                                                                        class="fa-regular fa-note-sticky"></i></button></a>

                                                            <?php if($suratkeluarr->status == auth()->user()->jabatan): ?>
                                                                <a
                                                                    href="<?php echo e(route('disposisi.tambah', ['id' => $suratkeluarr->id, 'jenis' => "surat keluar"])); ?>"><button
                                                                        class="btn btn-success"><i
                                                                            class="fa-solid fa-share-from-square"></i></button></a>
                                                            <?php endif; ?>
                                                            <a role="button" class="delete-button" data-bs-toggle="modal"
                                                                data-bs-target=".modal2<?php echo e($suratkeluarr->id); ?>">
                                                                <button class="btn btn-danger">
                                                                    <i class="fas fa-trash"></i>
                                                                </button>
                                                            </a>



                                                            <div class="modal fade modal2<?php echo e($suratkeluarr->id); ?>"
                                                                tabindex="-1" role="dialog" aria-hidden="true">
                                                                <div class="modal-dialog">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h5 class="modal-title"><strong>Hapus
                                                                                    Data</strong></h5>
                                                                            <button type="button" class="btn-close"
                                                                                data-bs-dismiss="modal"></button>
                                                                        </div>
                                                                        <div class="modal-body">Apakah anda yakin ingin
                                                                            menghapus data?
                                                                            <span
                                                                                class="badge bg-secondary"><?php echo e($suratkeluarr->nama_surat); ?></span>
                                                                        </div>
                                                                        <div class="modal-footer"
                                                                            style="left:0px; height: 80px;">
                                                                            <form
                                                                                action="<?php echo e(route('suratkeluar.destroy', $suratkeluarr->id)); ?>"
                                                                                method="POST">
                                                                                <?php echo method_field('DELETE'); ?>
                                                                                <?php echo csrf_field(); ?>
                                                                                <div
                                                                                    style="display: flex; justify-content: space-between;">
                                                                                    <button type="button"
                                                                                        class="btn submit-btn submit-btn-yes"
                                                                                        data-bs-dismiss="modal"
                                                                                        style="width: 49%;">Tidak</button>
                                                                                    <input type="submit"
                                                                                        class="btn submit-btn submit-btn-no"
                                                                                        value="Setujui" style="width: 49%;">
                                                                                </div>
                                                                            </form>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
            <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

            <script src="<?php echo e(asset('js/kelolasuratkeluar.js')); ?>"></script>

    </body>

    </html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\PTI_Doa-Ayah\resources\views/admin/suratkeluar/index.blade.php ENDPATH**/ ?>