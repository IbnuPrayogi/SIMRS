<?php $__env->startSection('content'); ?>
    <!DOCTYPE html>
    <html>

    <head>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.css">
        <link rel="stylesheet" href="css/daftarpermohonancuti.css">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    </head>

    <body>
        <div class="container py-12" style="background-color: blue; border-radius: 25px; height: 100vh;">
            <div class="card-header" style="background-color: blue; color: white; border-bottom: 2px solid white;">
            
                    <div style="text-align:center;">
                        <span class="font-weight-bold" style="font-size: 20px;">Daftar Permohonan Tukar Jaga</span>
                    </div>
        
                <br>
                <div class="row py-12">
                    <div class="col-lg-12 mx-auto">
                        <div class="card rounded shadow border-2" style="height: 85vh;margin-left:-25px;margin-right:-25px;">
                                    
                                    <div class="table-responsive">
                                        <table id="example" style="width: 100%"
                                            class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Nama Pengaju</th>
                                                    <th>Target Tukar Jaga</th>
                                                    <th>Keterangan</th>
                                                    <th>jadwal asli</th>
                                                    <th>jadwal dirubah</th>
                                                    <th>Status</th>
                                                    <th>Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $no = 1;
                                                ?>
                                                <?php $__currentLoopData = $TukarJagas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $TukarJaga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($no++); ?></td>
                                                        <td><?php echo e($TukarJaga->nama_pengaju); ?></td>
                                                        <td><?php echo e($TukarJaga->target_tukar_jaga); ?></td>
                                                        <td><?php echo e($TukarJaga->keterangan); ?></td>
                                                        <td><?php echo e($TukarJaga->jadwal_asli); ?></td>
                                                        <td><?php echo e($TukarJaga->jadwal_dirubah); ?></td>
                                                        <td><?php echo e($TukarJaga->status); ?></td>

                                                        <td>
                                                            <?php if($TukarJaga->status== auth()->user()->jabatan && $TukarJaga->status !='disetujui'): ?>
                                                            <?php if(auth()->user()->jabatan=='Direktur'): ?>
                                                            <a href="<?php echo e(route('PermohonanTukarJaga.priview', $TukarJaga->id)); ?>"><button
                                                                class="btn btn-warning" style="background:#1AACAC">
                                                                <i class="fa-solid fa-file-signature"></i></button></a>
                                                                
                                                            <?php endif; ?>
                                                            <a
                                                            href="<?php echo e(route('kbdisposisi.tambah', ['id' => $TukarJaga->id, 'jenis' => "surat tukar jaga"])); ?>"><button
                                                                class="btn btn-success"><i
                                                                    class="fa-solid fa-share-from-square"></i></button></a>
                                                                
                                                            <?php endif; ?>
                                                            
                                                            <?php if($TukarJaga->file): ?>
                                                                <a href="<?php echo e(route('PermohonanTukarJaga.download', ['id' => $TukarJaga->id, 'file' => $TukarJaga->file])); ?>"
                                                                    class="btn btn-success" target="_blank"><i
                                                                        class="fas fa-download"></i></a>
                                                            <?php endif; ?>

                                                            <a href="<?php echo e(route('kbdisposisi.showsurat', ['id' => $TukarJaga->id, 'nama' => $TukarJaga->nama_surat])); ?>"><button
                                                                class="btn btn-primary"><i
                                                                    class="fa-regular fa-note-sticky"></i></button></a>

                                                            
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sisipkan script untuk jQuery -->
            <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
            <!-- Sisipkan script untuk DataTables -->
            <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
            <!-- Sisipkan script untuk file JavaScript Anda -->
            <script src="js/daftarpermohonancuti.js"></script>
    </body>

    </html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appdashboardkabag', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\SIMRS\resources\views/Admin/DaftarPermohonanTukarJaga/indexTukarJaga.blade.php ENDPATH**/ ?>