<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <?php elseif(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
    <?php endif; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kalender Jadwal Kerja Karyawan - Index</title>
    <style>
        /* Updated Styles */
        table {
            border-collapse: collapse;
            width: 100%;
        }
    
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
    
        .employee-name, .jam-kerja {
            text-align: left;
            font-weight: normal;
            background-color: #0D72F2;
            color: white;
            padding: 8px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
    
        .header-row th, .header-row td {
            position: sticky;
            top: 0;
            background-color: #0D72F2;
            color: white;
            z-index: 2;
        }
    
        .content-row td {
            text-align: center;
        }
    
        @media only screen and (max-width: 600px) {
            #scheduleTable {
                font-size: 12px;
            }
    
            th, td {
                min-width: 30px;
                max-width: 100px;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }
    
            .content-row td {
                padding: 5px;
            }
        }
    </style>
    
    <script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>
</head>
<body>



<?php
    $selectedMonth = request('selectedMonth', now()->format('m'));
    $selectedYear = request('selectedYear', now()->format('Y'));
?>

<h5>Jadwal Karyawan Bulan
    <select id="selectMonth" onchange="updateTable()" value="<?php echo e($selectedMonth); ?>" style="font-size: 20px">
        <?php for($i = 1; $i <= 12; $i++): ?>
            <option value="<?php echo e($i); ?>" <?php echo e($selectedMonth == $i ? 'selected' : ''); ?>>
                <?php echo e(date('F', mktime(0, 0, 0, $i, 1))); ?>

            </option>
        <?php endfor; ?>
    </select>
    <label for="selectYear">Tahun:</label>
    <select id="selectYear" onchange="updateTable()" value="<?php echo e($selectedYear); ?>">
        <?php
            $currentYear = now()->format('Y');
        ?>

        <?php for($year = $currentYear - 5; $year <= $currentYear + 5; $year++): ?>
            <option value="<?php echo e($year); ?>" <?php echo e($selectedYear == $year ? 'selected' : ''); ?>>
                <?php echo e($year); ?>

            </option>
        <?php endfor; ?>
    </select>
</h5>

<style>
    /* Common Styles */
    .employee-name, .jam-kerja {
        text-align: left;
        font-weight: normal;
        background-color: #0D72F2;
        color: white;
        padding: 8px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .scrollable-table-container {
        overflow-x: auto;
        margin-top: 10px;
    }

    table {
        border-collapse: collapse;
        width: auto;
    }

    th, td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: center;
        font-weight: normal;
    }

    /* Fixed Column Styles */
    .fixed-column {
        position: sticky;
        left: 0;
        z-index: 1;
        background-color: #0D72F2;
        color: white;
    }

    .fixed-column th,
    .fixed-column td {
        white-space: nowrap;
    }

    .fixed-jam {
        position: sticky;
        left: 160px; /* Adjust as per your requirement */
        z-index: 1;
        background-color: #0D72F2;
        color: white;
    }

    /* Other Styles */
    .shift-dropdown {
        display: flex;
        justify-content: center;
    }

    .shift {
        width: 100%;
    }

    @media only screen and (max-width: 600px) {
        .fixed-jam {
            left: 100px;
        }
    }
</style>


<div class="scrollable-table-container">
    <table id="scheduleTable">
        <tr>
            <th class="fixed-column">Nama Karyawan</th>
            <th class="fixed-jam" style="width: 200px">Jam Kerja</th>
            <?php for($day = 1; $day <= cal_days_in_month(CAL_GREGORIAN, $selectedMonth, now()->format('Y')); $day++): ?>
                <th><?php echo e($day); ?><br>
                    <?php echo e(date('l', strtotime("$year-$selectedMonth-$day")) === 'Sunday' ? 'Minggu' :
                        (date('l', strtotime("$year-$selectedMonth-$day")) === 'Monday' ? 'Senin' :
                        (date('l', strtotime("$year-$selectedMonth-$day")) === 'Tuesday' ? 'Selasa' :
                        (date('l', strtotime("$year-$selectedMonth-$day")) === 'Wednesday' ? 'Rabu' :
                        (date('l', strtotime("$year-$selectedMonth-$day")) === 'Thursday' ? 'Kamis' :
                        (date('l', strtotime("$year-$selectedMonth-$day")) === 'Friday' ? 'Jumat' : 'Sabtu')))))); ?></th>
            <?php endfor; ?>
        </tr>

        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="fixed-column employee-name"><?php echo e($user->nama_karyawan); ?></td>
                <?php
                   $userSchedule = $jadwal->where('user_id', $user->id)->where('bulan', $selectedMonth)->where('tahun',$selectedYear)->first();
                    if ($userSchedule) {
                        $hours = floor($userSchedule->jumlah_jam_kerja / 60);
                        $minutes = $userSchedule->jumlah_jam_kerja % 60;
                    } else {
                        $hours = '0';
                        $minutes = '0';
                    }
                ?>
                <td class="fixed-jam jam-kerja"><?php echo e($hours.' jam'); ?></td>

                <?php for($day = 1; $day <= cal_days_in_month(CAL_GREGORIAN, $selectedMonth, now()->format('Y')); $day++): ?>
                    <td class="calendar-cell">
                        <?php
                            $userShift = $userSchedule ? $shifts->where('id', $userSchedule->{"tanggal_$day"})->first() : null;
                            $shiftId = $userShift ? $userShift->kode_shift : '-';
                        ?>
                        <?php echo e($shiftId); ?>

                    </td>
                <?php endfor; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<div style="border: 1px solid #000;padding: 5px;width:600px;margin-left:625px;margin-top:20px;">
    <div style="display: flex; justify-content: flex-end; margin-top: 20px;">
   
        <div style="display: flex; align-items: center; margin-right: 20px;">
            <div style="width: 20px; height: 20px; background-color: red; margin-right: 5px;"></div>
            <span>Alfa</span>
        </div>
        <div style="display: flex; align-items: center; margin-right: 5px;">
            <div style="width: 20px; height: 20px; background-color: yellow; margin-right: 5px;"></div>
            <span>Terlambat</span>
        </div>
        <div style="display: flex; align-items: center; margin-right: 5px;">
            <div style="width: 20px; height: 20px; background-color: green; margin-right: 5px;"></div>
            <span>Tepat Waktu</span>
        </div>
        <div style="display: flex; align-items: center; margin-right: 100px;">
            <div style="width: 20px; height: 20px; background-color: blue; margin-right: 5px;"></div>
            <span>Izin</span>
        </div>
        <div style="display: flex; align-items: center; margin-right: 50px;">
            <div style="width: 20px; height: 20px; background-color: purple; margin-right: 5px;"></div>
            <span>Cuti</span>
        </div>
    </div>
    
    <!-- Legend for Time Periods -->
    <div style="display: flex; justify-content: flex-end; margin-top: 5px;">
        <div style="display: flex; align-items: center; margin-right: 1px;">
            <div style="width: 20px; height: 20px;  margin-right: 5px;"></div>
            <span>P = Pagi</span>
        </div>
        <div style="display: flex; align-items: center; margin-right: 1px;">
            <div style="width: 20px; height: 20px; margin-right: 5px;"></div>
            <span>S = Siang</span>
        </div>
        <div style="display: flex; align-items: center; margin-right: 1px;">
            <div style="width: 20px; height: 20px;  margin-right: 5px;"></div>
            <span>M = Malam</span>
        </div>
        <div style="display: flex; align-items: center; margin-right: 1px;">
            <div style="width: 20px; height: 20px;  margin-right: 5px;"></div>
            <span>PM = Pagi Malam</span>
        </div>
        <div style="display: flex; align-items: center;">
            <div style="width: 20px; height: 20px; margin-right: 5px;"></div>
            <span>PS = Pagi Sore</span>
        </div>
    </div>
</div>

<a href="javascript:void(0);" onclick="downloadImage()" class="btn btn-primary">Download Image</a>
<a href="<?php echo e(route('kbjadwal.editjadwal', ['bulan' => $selectedMonth,'tahun'=>$selectedYear])); ?>" class="btn btn-primary">Edit Schedule</a>


</body>
<script>
    function downloadImage() {
        html2canvas(document.querySelector("#scheduleTable")).then(canvas => {
            var link = document.createElement('a');
            link.href = canvas.toDataURL("image/png");
            link.download = 'jadwal_karyawan.png';
            link.click();
        });
    }

    function updateTable() {
        var selectedMonth = document.getElementById('selectMonth').value;
        var selectedYear = document.getElementById('selectYear').value;
        window.location.href = window.location.pathname + '?selectedMonth=' + selectedMonth + '&selectedYear=' + selectedYear;
       
    }
</script>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appdashboardkabag', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\SIMRS\resources\views/kepalabagian/jadwal/index.blade.php ENDPATH**/ ?>