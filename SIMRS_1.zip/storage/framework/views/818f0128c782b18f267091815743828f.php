<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <?php elseif(session('successdelete')): ?>
    <div class="alert alert-success">
        <?php echo e(session('successdelete')); ?>

    </div>
    <?php endif; ?>

    <!DOCTYPE html>
    <html lang="en">
        <head>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.css">
            <link rel="stylesheet" href="css/arsip.css">
            <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
        </head>
        <?php
            $selectedMonth = request('selectedMonth', now()->format('m'));
            $selectedYear = request('selectedYear', now()->format('Y'));
        ?>

        <body>
            <div class="container py-5" style="background-color: blue; border-radius: 25px;">
                <div class="container py-6">
                    <div class="card-header" style="background-color: blue; color: white; border-bottom: 2px solid white;">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <span class="font-weight-bold" style="font-size: 30px;">Kelola Jadwal</span>
                            </div>
                            <div>
                                <form action="<?php echo e(route('statusjadwal.lockall')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('POST'); ?>
                                    <input type="hidden" name="bulan" value=<?php echo e($selectedMonth); ?>>
                                    <input type="hidden" name="tahun" value=<?php echo e($selectedYear); ?>>
                       
                                    <button class="button" id="openPopupButton"
                                        style="font-size: 15px; border-radius: 20px;">
                                        Kunci Jadwal Bulan Ini</button>
                                </form>
                                
                           
                            </div>
                        </div>

                    </div><br>
                    <div class="row py-6">
                        <div class="col-lg-12 mx-auto">
                            <div class="card rounded shadow border-2">
                                <div class="card-body p-5 bg-white rounded">
                                    <div class="table-responsive">
                                        <label for="selectMonth">Bulan:</label>
                                        <select id="selectMonth" onchange="updateTable()" value="<?php echo e($selectedMonth); ?>">
                                            <?php for($i = 1; $i <= 12; $i++): ?>
                                                <option value="<?php echo e($i); ?>" <?php echo e($selectedMonth == $i ? 'selected' : ''); ?>>
                                                    <?php echo e(date('F', mktime(0, 0, 0, $i, 1))); ?>

                                                </option>
                                            <?php endfor; ?>
                                        </select>
                                    
                                    
                                        <label for="selectYear">Tahun:</label>
                                        <select id="selectYear" onchange="updateTable()" value="<?php echo e($selectedYear); ?>">
                                            <?php
                                                $currentYear = now()->format('Y');
                                            ?>
                                    
                                            <?php for($year = $currentYear - 5; $year <= $currentYear + 5; $year++): ?>
                                                <option value="<?php echo e($year); ?>" <?php echo e($selectedYear == $year ? 'selected' : ''); ?>>
                                                    <?php echo e($year); ?>

                                                </option>
                                            <?php endfor; ?>
                                        </select>
                                        <table id="example" style="width: 100%"
                                            class="table table-striped table-bordered">

                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Nama Bagian</th>
                                                    <th>Status</th>
                                                    <th>Waktu Dibuat</th>
                                                    <th>Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $no = 1;
                                                ?>
                                                <?php $__currentLoopData = $bagians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bagian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($no++); ?></td>
                                                        <td><?php echo e($bagian->nama_bagian); ?></td>
                                                        <?php
                                                        $statusjadwal=$statusjadwals->where('nama_bagian',$bagian->nama_bagian)->first();
                                                        $status = $statusjadwal ? $statusjadwal->status : '-';
                                                        $waktu = $statusjadwal ? $statusjadwal->created_at : '-';
                                                        ?>
                                                        <td><?php echo e($status); ?></td>
                                                        <td><?php echo e($waktu); ?></td>
                                            

                                                        <td>
                                                            <a href="<?php echo e(route('bagian.edit', $bagian->id)); ?>"><button
                                                                    class="btn btn-primary">
                                                                    <i class="fas fa-eye"></i></button></a>
                                                            <?php if(!$statusjadwal || $statusjadwal->status=='terbuka'): ?>
                                                            <form action="<?php echo e(route('statusjadwal.lock')); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('POST'); ?>
                                                                <input type="hidden" name="bulan" value=<?php echo e($selectedMonth); ?>>
                                                                <input type="hidden" name="tahun" value=<?php echo e($selectedYear); ?>>
                                                                <input type="hidden" name="bagian" value=<?php echo e($bagian->nama_bagian); ?>>
                                                                <button type="submit"
                                                                    class="btn btn-danger">
                                                                    <i class="fas fa-lock"></i></button>
                                                            </form>
                                                            
                                                            <?php elseif($statusjadwal && $statusjadwal->status=='terkunci'): ?>
                                                            <form action="<?php echo e(route('statusjadwal.unlock')); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('POST'); ?>
                                                                <input type="hidden" name="bulan" value=<?php echo e($selectedMonth); ?>>
                                                                <input type="hidden" name="tahun" value=<?php echo e($selectedYear); ?>>
                                                                <input type="hidden" name="bagian" value=<?php echo e($bagian->nama_bagian); ?>>
                                                                <button type="submit"
                                                                    class="btn btn-success">
                                                                    <i class="fas fa-unlock"></i></button>
                                                            </form>
                                                            <?php endif; ?>
                                                         



                                                            <div class="modal fade bd-example-modal-sm<?php echo e($bagian->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
                                                                <div class="modal-dialog">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h5 class="modal-title"><strong>Hapus Data</strong></h5>
                                                                            <button type="button" class="btn-close" data-bs-dismiss="modal">
                                                                            </button>
                                                                        </div>
                                                                        <div class="modal-body">Apakah anda yakin ingin menghapus data?</div>
                                                                        <div class="modal-footer" style="left:0px; height: 80px;">
                                                                            <form action="<?php echo e(route('bagian.destroy', $bagian->id)); ?>" method="POST">
                                                                            <?php echo method_field('DELETE'); ?>
                                                                            <?php echo csrf_field(); ?>
                                                                            <div style="display: flex; justify-content: space-between;">
                                                                                <button type="button" class="btn submit-btn submit-btn-yes" data-bs-dismiss="modal" style="width: 49%;">Tidak</button>
                                                                                <input type="submit" class="btn submit-btn submit-btn-no" name="" id="" value="Hapus" style="width: 49%;">
                                                                            </div>

                                                                            </form>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
            <!-- Sisipkan script untuk DataTables -->
            <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
            <!-- Sisipkan script untuk file JavaScript Anda -->
            <script src="js/arsip.js"></script>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
        // Set nilai awal untuk dropdown
        document.getElementById('selectMonth').value = "<?php echo e($selectedMonth); ?>";
        document.getElementById('selectYear').value = "<?php echo e($selectedYear); ?>";
    
        // Panggil fungsi updateTable untuk memuat data tanpa merefresh halaman
        updateTable();
    });
    
    function updateTable() {
        var selectedMonth = document.getElementById('selectMonth').value;
        var selectedYear = document.getElementById('selectYear').value;
    
        var url = window.location.pathname + '?selectedMonth=' + selectedMonth + '&selectedYear=' + selectedYear;
    
        // Ubah URL tanpa merefresh halaman
        history.replaceState({}, '', url);
    
        // Gunakan fetch untuk memuat data
        fetch(url, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.text())
        .then(data => {
            // Ganti konten HTML tanpa merefresh halaman
            document.body.innerHTML = data;
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }
    
        </script>
        </body>
    </html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\SIMRS\resources\views/admin/statusjadwal/index.blade.php ENDPATH**/ ?>