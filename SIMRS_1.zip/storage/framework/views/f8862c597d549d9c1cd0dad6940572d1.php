<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.css">
    <link rel="stylesheet" href="css/home.css">

    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-6">
                <div class="small-box">
                    <div class="inner">
                        <h3><?php echo e($countUsers); ?></h3>
                        <p>Pengguna</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-bag"></i>
                    </div>
                    <a href="<?php echo e(route('user.index')); ?>" class="small-box-footer">Jumlah Pengguna <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <div class="col-lg-3 col-6">
                <div class="small-box">
                    <div class="inner">
                        <h3><?php echo e($countArsips); ?></h3>
                        <p>Arsip</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-stats-bars"></i>
                    </div>
                    <a href="<?php echo e(route('arsip.index')); ?>" class="small-box-footer">Jumlah Arsip <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <div class="col-lg-3 col-6">
                <div class="small-box">
                    <div class="inner">
                        <h3><?php echo e($countSuratMasuk); ?></h3>
                        <p>Surat Masuk</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-person-add"></i>
                    </div>
                    <a href="<?php echo e(route('suratkeluar.index')); ?>" class="small-box-footer">Jumlah Surat Masuk <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <div class="col-lg-3 col-6">
                <div class="small-box">
                    <div class="inner">
                        <h3><?php echo e($countSuratKeluar); ?></h3>
                        <p>Surat Keluar</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-pie-graph"></i>
                    </div>
                    <a href="<?php echo e(route('suratmasuk.index')); ?>" class="small-box-footer">Jumlah Surat Keluar <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
        </div>

        

        <!-- Sisipkan script untuk Chart.js (jika belum ada) -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js"></script>
        



    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\PTI_Doa-Ayah\resources\views/admin/index.blade.php ENDPATH**/ ?>