<!-- resources/views/schedule/download.blade.php -->

Jadwal Karyawan Bulan <?php echo e(now()->format('F')); ?> - Download

<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($user->nama_karyawan); ?>

    <?php for($day = 1; $day <= cal_days_in_month(CAL_GREGORIAN, now()->format('m'), now()->format('Y')); $day++): ?>
        <?php
            $userSchedule = $jadwal->where('user_id', $user->id)->first();
            $userShift = $shifts->where('id', $userSchedule->{"tanggal_$day"})->first();
            $shiftId = $userSchedule ? $userShift->kode_shift : '-';
        ?>
        <?php echo e($shiftId); ?>

    <?php endfor; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\laravel\SIMRS\resources\views/admin/jadwal/download.blade.php ENDPATH**/ ?>