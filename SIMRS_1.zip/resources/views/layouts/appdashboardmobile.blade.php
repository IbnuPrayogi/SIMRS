<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'dashboard') }}</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <!-- Styles -->
    <link rel="stylesheet" href="{{ asset('css/dashboardmobile.css') }}">
    {{-- <link rel="stylesheet" href="css/cutimobile.css"> --}}

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <!-- Scripts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

</head>

<body
    style="background-image: url('{{ asset('img/bg.jpeg') }}');
             background-size: cover;
             background-position: center;
             background-repeat: no-repeat;
             ">
    <div id="app">
        <div class="upbar">
            <div class="logo_aplikasi">
                <img src="{{ asset('img/logo.png') }}" alt="logo" style="width:100%; height:100%;" />
            </div>
            <div class="atur_jarak">
                <p>RS Islam Asy-syifa</p>
            </div>
            @php
            $fotoUser = auth()->user()->foto;
            $path = 'assets/profil/'.$fotoUser;
            @endphp

            <div class="elips" style=" margin-right:10px;">
                <a href="/profile"><img src="{{ asset(file_exists($path) ? $path : 'assets/profil/pp.jpg') }}"alt="logo_user"></a>
            </div>
            <div class="dropdown" style="margin-right: 25px">
                <div class="menu">
                    <i class="fa-solid fa-chevron-down"></i>
                </div>
                <div class="dropdown-content">
                    <div class="notif_text">
                        <h1>Sistem Informasi Manajemen Kehadiran</h1>
                    </div>
                    <div class="line"></div>
                    <div class="icon-exit">
                        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                            @csrf
                            <a href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="fa-solid fa-arrow-right-from-bracket"></i>
                                <h1>Keluar</h1>
                            </a>
                        </form>
                    </div>
                    
                </div>
            </div>
        </div>

        <div class="navbar-content" style="margin-bottom: -40px;margin-left:23px">
            <div class="navbar">
                <a href="/home" class="{{ Request::is('/home') ? 'active' : '' }}"><i class='bx bx-home'></i></a>
                <a href="/buatpengajuansurat" class="{{ Request::is('/pengajuan') ? 'active' : '' }}"><i class="fas fa-plus add-file-icon"></i></a>
                <a href="/presensi/karyawan/detail" class="{{ Request::is('/status') ? 'active' : '' }}"><i class="fa-solid fa-list-check"></i></a>
                <a href="/profile" class="{{ Request::is('/profile') ? 'active' : '' }}"><i class='bx bxs-user' ></i></a>
            </div>
        </div>

        <main class="py-4">
            @yield('content')
        </main>
        
    </div>

    <script>
        // Mengambil elemen tombol dropdown
        var dropdownButton = document.querySelector(".menu i");

        // Mengambil elemen isi dropdown
        var dropdownContent = document.querySelector(".dropdown-content");

        // Menambahkan event listener untuk tombol dropdown
        dropdownButton.addEventListener("click", function() {
            // Memeriksa apakah isi dropdown sedang ditampilkan atau tidak
            if (dropdownContent.style.display === "block") {
                dropdownContent.style.display = "none"; // Jika ditampilkan, sembunyikan
            } else {
                dropdownContent.style.display = "block"; // Jika tidak ditampilkan, tampilkan
            }
        });
    </script>
</body>

</html>
