<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.css">
    <link rel="stylesheet" href="css/home.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
      canvas {
        max-width: 100%;
        margin: 20px 0;
      }
    </style>

    <?php
        
    ?>


    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-6">
                <div class="small-box">
                    <div class="inner">
                        <h3><?php echo e($jumlahAdmin); ?></h3>
                        <p>Admin</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-bag"></i>
                    </div>
                    <a href="<?php echo e(route('user.index')); ?>" class="small-box-footer">Jumlah Admin <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <div class="col-lg-3 col-6">
                <div class="small-box">
                    <div class="inner">
                        <h3><?php echo e($jumlahUser); ?></h3>
                        <p>Karyawan</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-stats-bars"></i>
                    </div>
                    <a href="<?php echo e(route('arsip.index')); ?>" class="small-box-footer">Jumlah Karyawan <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <div class="col-lg-3 col-6">
                <div class="small-box">
                    <div class="inner">
                        <h3><?php echo e($jumlahShift); ?></h3>
                        <p>Shift</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-person-add"></i>
                    </div>
                    <a href="<?php echo e(route('suratkeluar.index')); ?>" class="small-box-footer">Jumlah Shift <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <div class="col-lg-3 col-6">
                <div class="small-box">
                    <div class="inner">
                        <h3><?php echo e($jumlahShift); ?></h3>
                        <p>Telat</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-pie-graph"></i>
                    </div>
                    <a href="<?php echo e(route('suratmasuk.index')); ?>" class="small-box-footer">Jumlah Telat <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
        </div>

        
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header" style="background-color: #0051B9;color:white">
                            <h4 class="card-title">Telat Hari Ini</h4>
                        </div>
                        <div class="card rounded shadow border-2">
                            <div class="card-body p-9 bg-white rounded">
                        <div class="table-responsive">
                            <table id="example" style="width: 100%"
                                class="table table-striped table-bordered">

                                <thead>
                                    <tr>
                                       
                                        <th>Nama</th>
                                        <th>Bagian</th>
                                        <th>Shift</th>
                                        <th>Waktu</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $dataTerlambat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $terlambat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <?php
                                            $shift= \App\Models\Shift::where('id',$terlambat->shift_id)->first();
                                            $user=\App\Models\User::where('nama_karyawan',$terlambat->nama_karyawan)->first();
                                        ?>
                                     
                                        <td><?php echo e($terlambat->nama_karyawan); ?></td>
                                        <td><?php echo e($user->nama_bagian); ?></td>
                                        <td><?php echo e($shift->nama_shift); ?></td>
                                        <td><?php echo e($terlambat->waktu_terlambat); ?></td>
                                    </tr>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                </tbody>
                            </table>
                        </div>  
                        </div>
                    </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header" style="background-color: #0051B9;color:white">
                            <h4 class="card-title">Karyawan Sesuai Shift</h4>
                        </div>
                        <div style="text-align: center;">
                            <!-- Tambahkan elemen canvas sebagai tempat diagram batang -->
                            <canvas id="barChart"></canvas>
                          </div>
                        
                          <script>
                            // Data untuk diagram batang
                            var dynamicData = <?php echo json_encode($dynamicsData, 15, 512) ?>;
                            var data = {
                              labels: ["Pagi", "Sore", "Malam", "Pagi/Sore", "Pagi/Malam"],
                              datasets: [{
                                label: 'Shift Karyawan',
                                data: dynamicData, // Tinggi untuk setiap kategori
                                backgroundColor: [
                                  'rgba(255, 99, 132, 0.7)',
                                  'rgba(54, 162, 235, 0.7)',
                                  'rgba(255, 206, 86, 0.7)',
                                  'rgba(75, 192, 192, 0.7)',
                                  'rgba(153, 102, 255, 0.7)',
                                ],
                                borderColor: [
                                  'rgba(255, 99, 132, 1)',
                                  'rgba(54, 162, 235, 1)',
                                  'rgba(255, 206, 86, 1)',
                                  'rgba(75, 192, 192, 1)',
                                  'rgba(153, 102, 255, 1)',
                                ],
                                borderWidth: 1
                              }]
                            };
                        
                            // Konfigurasi untuk diagram batang
                            var options = {
                              scales: {
                                y: {
                                  beginAtZero: true
                                }
                              }
                            };
                        
                            // Mengambil elemen canvas
                            var ctx = document.getElementById('barChart').getContext('2d');
                        
                            // Membuat objek diagram batang
                            var barChart = new Chart(ctx, {
                              type: 'bar',
                              data: data,
                              options: options
                            });
                          </script>
                    </div>
                </div>
            </div>
        </div> 

        <!-- Sisipkan script untuk Chart.js (jika belum ada) -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js"></script>
        



    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\SIMRS\resources\views/admin/index.blade.php ENDPATH**/ ?>