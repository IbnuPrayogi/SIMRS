<!-- resources/views/schedule/index.blade.php -->





<?php
function getColorClass($status) {
    switch ($status) {
        case 'tepat waktu':
            return 'green';
        case 'alfa':
            return 'red';
        case 'izin':
            return 'blue';
        case 'cuti':
            return 'black';
        default:
            return 'yellow';
    }
}
?>

<?php $__env->startSection('content'); ?>
    <!DOCTYPE html>
    <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Kalender Jadwal Kerja Karyawan - Index</title>
            <style>
                /* Updated Styles */
                table {
                    border-collapse: collapse;
                    width: 100%;
                }
        
                th, td {
                    border: 1px solid #dddddd;
                    text-align: left;
                    padding: 5px;
                    font-weight: normal;
                }
        
                .employee-name {
                    font-weight: normal;
                    background-color: #0D72F2;
                    color: white;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }
        
                .calendar-cell {
                    text-align: center;
                }
                /* Updated Styles */
            </style>
            <script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>
        </head>

        <body>
        <?php
            $selectedMonth = request('selectedMonth', now()->format('m'));
            $selectedYear = request('selectedYear', now()->format('Y'));
            $selectedDepartment = request('selectedDepartment', 'Satpam');
            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $selectedMonth, $selectedYear);
        ?>
      
                

        <h5>Jadwal Karyawan Bulan 


            <select id="selectMonth" onchange="updateTable()">
                <?php for($i = 1; $i <= 12; $i++): ?>
                    <option value="<?php echo e($i); ?>" <?php echo e($selectedMonth == $i ? 'selected' : ''); ?>>
                        <?php echo e(date('F', mktime(0, 0, 0, $i, 1))); ?>

                    </option>
                <?php endfor; ?>
            </select>


            <label for="selectYear">Tahun:</label>
            <select id="selectYear" onchange="updateTable()" value="<?php echo e($selectedYear); ?>">
                <?php
                    $currentYear = now()->format('Y');
                ?>

                <?php for($year = $currentYear - 5; $year <= $currentYear + 5; $year++): ?>
                    <option value="<?php echo e($year); ?>" <?php echo e($selectedYear == $year ? 'selected' : ''); ?>>
                        <?php echo e($year); ?>

                    </option>
                <?php endfor; ?>
            </select>

            <label for="selectDepartment">Bagian:</label>
            <select id="selectDepartment" onchange="updateTable()">
                <?php $__currentLoopData = $bagians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($department->nama_bagian); ?>" <?php echo e($selectedDepartment == $department->nama_bagian ? 'selected' : ''); ?>>
                        <?php echo e($department->nama_bagian); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            
        </h4>

        <table id="scheduleTable">
            <tr>
                <th></th>
                <?php for($day = 1; $day <= $daysInMonth; $day++): ?>
                    <th><?php echo e($day); ?></th>
                <?php endfor; ?>
                <th>Terlambat</th> <!-- Kolom terlambat -->
                <th>Terpotong</th>
                <th>Izin</th>
            </tr>

            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $userSchedule = $jadwal->where('nama_karyawan', $user->nama_karyawan)->first();
            ?>
                <tr>
                    <td class="employee-name"><?php echo e($user->nama_karyawan); ?></td>

                    <?php
                        $totalTerlambat = \App\Models\Terlambat::where('nama_karyawan', $user->nama_karyawan)
                            ->where('tanggal','like',"%/$selectedMonth/%")
                            ->sum('waktu_terlambat');
                        $totalTerpotong = \App\Models\Potongan::where('nama_karyawan', $user->nama_karyawan)
                            ->where('tanggal','like',"%/$selectedMonth/%")
                            ->sum('waktu_potongan');
                        $totalIzin = \App\Models\Izin::where('nama_karyawan', $user->nama_karyawan)
                            ->where('tanggal','like',"%/$selectedMonth/%")
                            ->sum('waktu_izin');
                    ?>



                    <?php for($day = 1; $day <= $daysInMonth; $day++): ?>
                        <?php
                            $date = $day . "/" . $selectedMonth . "/" . $selectedYear;
                            $datapresensi = $presensi->where('id_karyawan', $user->id)->where('tanggal', $date)->first();
                        ?>
                        <td class="calendar-cell" style="background-color: <?php echo e($datapresensi ? getColorClass($datapresensi->status) : 'white'); ?>">


                        
                            <?php
                                
                                $userShift = $userSchedule ? $shifts->where('id', $userSchedule->{"tanggal_$day"})->first() : null;
                                $shiftId = $userShift ? $userShift->kode_shift : '-';
                            ?>
                            <?php echo e($shiftId); ?>

                        </td>
                    <?php endfor; ?>

                    <!-- Kolom terlambat -->
                    <td><?php echo e($totalTerlambat); ?> jam</td>
                    <td><?php echo e($totalTerpotong); ?> jam</td>
                    <td><?php echo e($totalIzin); ?> jam</td>
                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <br>
        <a href="javascript:void(0);" onclick="downloadImage()" class="btn btn-primary">Download Image</a>

        <form id="storePresensiForm" method="post" action="<?php echo e(route('presensi.store')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <input type="hidden" name="bulan" id="bulanInput">
            <input type="hidden" name="tahun" id="tahunInput">

            <button class="btn btn-primary" type="button" onclick="storePresensi()">Rekap Data Presensi</button>
        </form>

        <form id="fetchPresensiForm" method="get" action="<?php echo e(url('presensi/ambil')); ?>" enctype="multipart/form-data">

            <button class="btn btn-primary" type="button" onclick="fetchPresensi()">Ambil Data Presensi</button>
        </form>

        <button id="callLocalRouteButton">Call Local Route</button>


        </body>

        <script>
            function fetchPresensi() {
                var selectedMonth = document.getElementById('selectMonth').value;
                var selectedYear = document.getElementById('selectYear').value;
        
                // Build the new URL without any conditions
                var newURL = "<?php echo e(url('presensi/take')); ?>/" + selectedMonth + "/" + selectedYear;
        
                // Navigate to the new URL
                window.location.href = newURL;
            }

            function storePresensi() {
                var selectedMonth = document.getElementById('selectMonth').value;
                var selectedYear = document.getElementById('selectYear').value;

                // Log the values to check if they are correct
                console.log("Selected Month:", selectedMonth);
                console.log("Selected Year:", selectedYear);

                // Set the values of hidden inputs
                document.getElementById('bulanInput').value = selectedMonth;
                document.getElementById('tahunInput').value = selectedYear;

                // Submit the form
                document.getElementById('storePresensiForm').submit();
            }

            document.getElementById('callLocalRouteButton').addEventListener('click', function() {
                fetch('http://localhost:8000/presensi/fetch/12/2023', {
                method: 'GET',
                // Tambahkan header atau opsi lain jika diperlukan
                })
                .then(response => response.json())
                .then(data => {
                console.log(data);
                // Lakukan sesuatu dengan respons yang diterima
                })
                .catch(error => {
                console.error('Error:', error);
                });
            });


        </script>

        
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                // Set nilai awal untuk dropdown
                document.getElementById('selectMonth').value = "<?php echo e($selectedMonth); ?>";
                document.getElementById('selectYear').value = "<?php echo e($selectedYear); ?>";
                document.getElementById('selectDepartment').value = "<?php echo e($selectedDepartment); ?>";
        
                // Simpan state sebelumnya
                var prevState = {
                    selectedMonth: "<?php echo e($selectedMonth); ?>",
                    selectedYear: "<?php echo e($selectedYear); ?>",
                    selectedDepartment: "<?php echo e($selectedDepartment); ?>"
                };
        
                // Tambahkan event listener untuk setiap dropdown
                document.getElementById('selectMonth').addEventListener('change', function () {
                    updateTable(prevState);
                });
                document.getElementById('selectYear').addEventListener('change', function () {
                    updateTable(prevState);
                });
                document.getElementById('selectDepartment').addEventListener('change', function () {
                    updateTable(prevState);
                });
        
                // Panggil fungsi updateTable untuk memperbarui URL
                updateTable(prevState);
            });
        
            function downloadImage() {
                html2canvas(document.querySelector("#scheduleTable")).then(canvas => {
                    var link = document.createElement('a');
                    link.href = canvas.toDataURL("image/png");
                    link.download = 'jadwal_karyawan.png';
                    link.click();
                });
            }
        
            function updateTable(prevState) {
                var selectedMonth = document.getElementById('selectMonth').value;
                var selectedYear = document.getElementById('selectYear').value;
                var selectedDepartment = document.getElementById('selectDepartment').value;
        
                var url = window.location.pathname + '?selectedMonth=' + selectedMonth + '&selectedYear=' + selectedYear;
        
                if (selectedDepartment) {
                    url += '&selectedDepartment=' + selectedDepartment;
                }
        
                // Gunakan AJAX untuk memuat data tanpa merefresh seluruh halaman
                fetch(url, {
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(response => response.text())
                .then(data => {
                    // Buat elemen div sementara untuk menyimpan data HTML baru
                    var tempDiv = document.createElement('div');
                    tempDiv.innerHTML = data;
        
                    // Ganti isi HTML tabel dengan yang baru
                    var newTable = tempDiv.querySelector('#scheduleTable');
                    document.getElementById('scheduleTable').innerHTML = newTable.innerHTML;
        
                    // Inisialisasi ulang elemen atau script yang diperlukan di sini
                    // Misalnya, jika ada script yang perlu dijalankan, pastikan inisialisasi dilakukan di sini.
                })
                .catch(error => {
                    console.error('Error:', error);
                });
            }
        </script>
        
    </html>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\SIMRS\resources\views/admin/presensi/index.blade.php ENDPATH**/ ?>