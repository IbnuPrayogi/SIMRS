<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.css">
<link  rel="stylesheet" href="<?php echo e(asset('css/presensi.css')); ?>">

<div class="container">
    <div class="card-header">
        <h1><b>Presensi</b></h1>
    </div>
    <div class="card-body">
        <?php
            $selectedMonth = request('selectedMonth', now()->format('m'));
            $selectedYear = request('selectedYear', now()->format('Y'));
            $selectedDepartment = request('selectedDepartment', 'Satpam');
            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $selectedMonth, $selectedYear);
        ?>

        <h4 style="margin-top: 20px;margin-left: 17px;">Bulan 
            <select id="selectMonth" onchange="updateTable()" value="<?php echo e($selectedMonth); ?>">
                <?php for($i = 1; $i <= 12; $i++): ?>
                    <option value="<?php echo e($i); ?>" <?php echo e($selectedMonth == $i ? 'selected' : ''); ?>>
                        <?php echo e(date('F', mktime(0, 0, 0, $i, 1))); ?>

                    </option>
                <?php endfor; ?>
            </select>

            <label for="selectYear">Tahun:</label>
            <select id="selectYear" onchange="updateTable()" value="<?php echo e($selectedYear); ?>">
                <?php
                    $currentYear = now()->format('Y');
                ?>

                <?php for($year = $currentYear - 5; $year <= $currentYear + 5; $year++): ?>
                    <option value="<?php echo e($year); ?>" <?php echo e($selectedYear == $year ? 'selected' : ''); ?>>
                        <?php echo e($year); ?>

                    </option>
                <?php endfor; ?>
            </select>
        </h4>

        <div class="table-container" style="max-height: 35rem; overflow: auto;">
            <table>
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>Shift</th>
                        <th>Status</th>
                        <th>Detail</th>
                    </tr>
                </thead>
                <tbody>
                    <?php for($day = 1; $day <= $daysInMonth; $day++): ?>
                        <?php
                            $date = $day . "/" . $selectedMonth . "/" . $selectedYear;
                            $datapresensi=null;
                            if($presensi!=null){
                                $datapresensi = $presensi->where('nama_karyawan', $jadwal->nama_karyawan)->where('tanggal', $date)->first();
                            }
                            $userShift = $jadwal ? $shift->where('id', $jadwal->{"tanggal_$day"})->first() : null;
                            $shiftId = $userShift ? $userShift->kode_shift : '-';
                            $presensiId = $datapresensi ? $datapresensi->status : '-';
                        ?>
                        <tr>
                            <td><?php echo e($day); ?></td>
                            <td><?php echo e($shiftId); ?></td>
                            <td><?php echo e($presensiId); ?></td>
                            <td>
                                <button class="detail-button">
                                    <i class="fas fa-eye"></i> 
                                </button>
                            </td>
                        </tr>
                    <?php endfor; ?>
                </tbody>
            </table>
        </div>

    </div>
    <!-- Sertakan ikon mata (eye) dari Font Awesome -->
    <script src="https://kit.fontawesome.com/your-font-awesome-kit-id.js" crossorigin="anonymous"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
    // Set nilai awal untuk dropdown
    document.getElementById('selectMonth').value = "<?php echo e($selectedMonth); ?>";
    document.getElementById('selectYear').value = "<?php echo e($selectedYear); ?>";

    // Panggil fungsi updateTable untuk memuat data tanpa merefresh halaman
    updateTable();
});

function updateTable() {
    var selectedMonth = document.getElementById('selectMonth').value;
    var selectedYear = document.getElementById('selectYear').value;

    var url = window.location.pathname + '?selectedMonth=' + selectedMonth + '&selectedYear=' + selectedYear;

    // Ubah URL tanpa merefresh halaman
    history.replaceState({}, '', url);

    // Gunakan fetch untuk memuat data
    fetch(url, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.text())
    .then(data => {
        // Ganti konten HTML tanpa merefresh halaman
        document.body.innerHTML = data;
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

    </script>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appdashboardmobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\SIMRS\resources\views/karyawan/presensi.blade.php ENDPATH**/ ?>