<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kalender Jadwal Kerja Karyawan</title>
    <style>
        /* Styles remain unchanged */

        .employee-name {
            /* Updated styling for employee name */
            text-align: left;
            font-weight: bold;
            background-color: #4CAF50;
            color: white;
            padding: 8px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        /* Styles remain unchanged */
    </style>
</head>
<body>
<?php
$users = App\Models\User::all();

// Fetch shift data from the database
$shifts = App\Models\Shift::all();
?>

<form method="post" action="<?php echo e(route('jadwal.store')); ?>">
    <?php echo csrf_field(); ?>

    <h2>Jadwal Karyawan Bulan <?php echo e(now()->format('F')); ?></h2>

    <table>
        <tr>
            <th></th>
            <?php for($day = 1; $day <= cal_days_in_month(CAL_GREGORIAN, now()->format('m'), now()->format('Y')); $day++): ?>
                <th><?php echo e($day); ?></th>
            <?php endfor; ?>
        </tr>

        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="employee-name"><?php echo e($user->nama_karyawan); ?></td>

                <?php for($day = 1; $day <= cal_days_in_month(CAL_GREGORIAN, now()->format('m'), now()->format('Y')); $day++): ?>
                    <td class="calendar-cell">
                        <div class="shift-dropdown">
                            <select class="shift" name="jadwal[<?php echo e($user->id); ?>][<?php echo e($day); ?>]">
                                <?php $__currentLoopData = $shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shiftOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($shiftOption->id); ?>"><?php echo e($shiftOption->kode_shift); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </td>
                <?php endfor; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <input type="hidden" name="bulan" value="<?php echo e(now()->month); ?>">

    <button type="submit">Simpan Jadwal</button>
</form>

<script>
    function changeShift(shiftId, userName, day) {
        // Implement your logic here to handle the shift change
        console.log('Selected Shift:', shiftId, 'for', userName, 'on day ' + day + ':', shiftId);
    }
</script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\SIMRS\resources\views/welcome.blade.php ENDPATH**/ ?>