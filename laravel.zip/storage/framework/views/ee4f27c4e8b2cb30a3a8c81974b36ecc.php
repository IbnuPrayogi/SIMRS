<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Template Surat</title>
    <link rel="stylesheet" href="<?php echo e(public_path('css/templatetukarjaga.css')); ?>">
</head>

<body>
    <div class="blangko">
        <p>BLANGKO TUKAR DINAS/TUKAR JAGA BAGIAN/RUANG ...............</p>
    </div>
    <div class="isi">
        <table>
            <tr>
                <th>Nama Karyawan</th>
                
                <th>Jadwal Asli</th>
                
                <th>Jadwal yang dirubah/diganti</th>
            </tr>
            <tr>
                <td><?php echo e($suratTukarJaga->nama_pengaju); ?></td>
                
                
                <td><?php echo e($suratTukarJaga->jadwal_asli); ?></td>
                <td><?php echo e($suratTukarJaga->jadwal_dirubah); ?></td>

            </tr>
            <tr>
                <th>Nama Karyawan</th>
                
                <th>Jadwal Asli</th>
                
                <th>Jadwal yang dirubah/diganti</th>
            </tr>
            <tr>
                <td><?php echo e($suratTukarJaga->target_tukar_jaga); ?></td>
                
                <td><?php echo e($suratTukarJaga->jadwal_dirubah); ?></td>
                
                <td><?php echo e($suratTukarJaga->jadwal_asli); ?></td>
            </tr>
        </table>
        <p>Tgl. PENYERAHAN BLANKO</p>
        <div class="tgl_blangko">
            <p>ini tanggal penyerahan</p>
        </div>
        <div class="ttd_A">
            <p>Yang Memohon, <b><?php echo e($suratTukarJaga->nama_pengaju); ?></b>
            </p>
            <p>
                <?php if($suratTukarJaga->tanda_tangan): ?>
                    <img style="height: 120px ; width:120px;"
                        src="<?php echo e(public_path('img/' . $suratTukarJaga->tanda_tangan)); ?>" alt="Tanda Tangan">
                <?php endif; ?>
            </p>
            <b><?php echo e($suratTukarJaga->nama_pengaju); ?></b>

            <div class="line"></div>
        </div>
        <div class="ttd_B">
            <p>Termohon, <b><?php echo e($suratTukarJaga->target_tukar_jaga); ?><b></p>
            <br><br>
            <div class="line"></div>
        </div>

        <div class="ttd_kar">
            <p>Ka. Ruangan</p>
            <br><br>
            <div class="line"></div>
        </div>
        <div class="ttd_kab">
            <p>Ka. Bagian</p>
            <br><br>
            <div class="line"></div>
        </div>
        </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravel\SIMRS\resources\views/karyawan/SuratTukarJaga/templatetukarjaga.blade.php ENDPATH**/ ?>