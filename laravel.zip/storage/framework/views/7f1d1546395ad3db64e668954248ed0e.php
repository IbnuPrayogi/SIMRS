<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Import SQL Table Form</title>
</head>
<body>
    <?php if(session('error')): ?>
        <p style="color: red;"><?php echo e(session('error')); ?></p>
    <?php endif; ?>
    <?php if(session('success')): ?>
        <p style="color: green;"><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <form method="post" action="<?php echo e(route('jadwal.importsql')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label for="sql_file">Upload SQL File:</label><br>
        <input type="file" name="sql_file"><br><br>
        <button type="submit">Import SQL Table</button>
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\SIMRS\resources\views/admin/jadwal/create.blade.php ENDPATH**/ ?>