<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Template Surat</title>
</head>
<body>
    <div class="container_izin">
        <p style="margin-left:65%">Karang Endah, <?php echo e(\Carbon\Carbon::parse($suratIzin->updated_at)->format('d-m-Y')); ?> 
        </p>
        <div class="kepada">
            <p> Kepada Yth,<br>
                Ibu Direktur RS. Islam Asy-Syifaa<br>
                Di<br>
                Tempat
            </p>
        </div>
        <p><b>Assalamu’alaikum Wr. Wb.</b></p>
        <p> Saya yang bertandatangan di bawah ini:</p>
        <p>Nama Pengaju : <?php echo e($suratIzin->nama_pengaju); ?> <br>
            Bagian      : <?php echo e($suratIzin->bagian); ?>

        </p>
        <div class="keterangan">
            <p>Bersama Surat ini Saya sampaikan bahwa pada tanggal <b><?php echo e(\Carbon\Carbon::parse($suratIzin->tanggal_izin)->format('d-m-Y')); ?></b> Saya tidak
                dapat bekerja seperti biasa,
                dikarenakan ada <b><?php echo e($suratIzin->keterangan); ?></b>. Mohon kiranya Ibu Direktur dapat memberikan izin kepada
                Saya.
            </p>
        </div>
        <p>Demikian Surat ini Saya sampaikan, atas Izin yang diberikan saya ucapkan terima kasih.</p>
        <p><b>Wassalamu’alaikum Wr. Wb.</b></p>
        <div class="tanda_tangan">
            <div class="ttd_aju">
                <p> Mengetahui,<br>
                    Manager Keuangan Umum & Personalia
                    <div class="kotak">
                        <?php if($suratIzin->manajer): ?>
                        <img style="height: 120px ; width:120px;"
                        src="<?php echo e(asset('assets/ttd/'.$suratIzin->manajer)); ?>"
                        alt="Tanda Tangan">
                        <?php else: ?>
                        <form method="POST" action="<?php echo e(route("PermohonanIzin.Sign",['id' => $suratIzin->id])); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <button type="submit">Tanda Tangani</button>
                        </form>
                        <form method="POST" action="<?php echo e(route('PermohonanIzin.Tolak', ['id' => $suratIzin->id])); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <button type="submit">Tolak</button>
                        </form>
                        <?php endif; ?>

                    </div>
                    <b>Nurul Hakim, SE</b>
                </p>
            </div>
            <div class="ttd_nama">
                <p> <br>
                    Hormat Saya,
                    <br>
                </p>
                <p>
                        <img style="height: 120px ; width:120px;"
                        src="<?php echo e(asset('assets/ttd/'.$suratIzin->tanda_tangan)); ?>"
                        alt="Tanda Tangan">
                </p>
                <b><?php echo e($suratIzin->nama_pengaju); ?></b>
                <p></p>
            </div>
        </div>
    </div>
</body>
</html>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appdashboardkabag', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\PTI_Doa-Ayah\resources\views/admin/DaftarPermohonanIzin/priview.blade.php ENDPATH**/ ?>