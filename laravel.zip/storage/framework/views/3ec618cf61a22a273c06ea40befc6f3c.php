<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.css">
<link rel="stylesheet" href="css/buatpengajuan.css">

<div class="container">
    <div class="card-header">
        <h1><b>Lihat Status</b></h1>
    </div>
    <div class="card-body">
        <div class="card-content">
            <h2>Tukar Jaga</h2>
            <a href="<?php echo e(route('status.tukarjaga',['id'=>auth()->user()->id])); ?>"><i class='bx bx-right-arrow-circle' ></i></a>
        </div>
        <div class="card-content">
            <h2>Permohonan Cuti</h2>
            <a href="<?php echo e(route('status.cuti',['id'=>auth()->user()->id])); ?>"><i class='bx bx-right-arrow-circle' ></i></a>
        </div>
        <div class="card-content">
            <h2>Permohonan Izin</h2>
            <a href="<?php echo e(route('status.izin',['id'=>auth()->user()->id])); ?>"><i class='bx bx-right-arrow-circle' ></i></a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appdashboardmobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\SIMRS\resources\views/karyawan/lihatstatusmobile.blade.php ENDPATH**/ ?>